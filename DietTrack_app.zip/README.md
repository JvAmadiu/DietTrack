# DietTrack

Aplicativo web responsivo com suporte a instalação como PWA.

## Executar
1. Extraia o ZIP.
2. Sirva a pasta por um servidor HTTP local (não abra apenas via `file://`). Ex.: `python -m http.server 8000`.
3. Acesse `http://localhost:8000`.
4. No celular, abra o endereço servido pela rede local ou publique em HTTPS e use “Adicionar à tela inicial”.

## Recursos
- Metas diárias e mensais de kcal e macronutrientes.
- Limites independentes por refeição e divisão automática.
- Indicadores visuais por refeição e painel diário.
- Banco local de alimentos de referência baseado em itens comuns da TACO (valores aproximados por 100 g).
- Entrada por texto para quantidades em gramas e alimentos reconhecidos.
- Consulta de industrializados pela API Open Food Facts (requer internet).
- Repetir refeição do dia anterior, histórico, exportação e importação JSON.
- Persistência local em IndexedDB e cache básico PWA.

## Limitações importantes
- O banco incluído é uma seleção demonstrativa de alimentos e valores de referência, não a base TACO integral/licenciada. Verifique a preparação e os valores nutricionais.
- A leitura de código de barras é feita por digitação ou por um leitor/câmera externo do dispositivo; não há scanner de câmera integrado nesta versão.
- A interpretação textual é baseada em correspondência simples, não em IA; frases com itens fora do banco não serão reconhecidas.
- O armazenamento é por navegador/dispositivo. Use exportação/importação para backup. Não há sincronização em nuvem nem contas multiusuário.
- O histórico registra dados locais e calcula adesão calórica; não substitui avaliação nutricional profissional.
